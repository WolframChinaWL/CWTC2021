#include <LTemplate.h>
#include <numeric>
#include <iomanip>


class sandpile {
public:

    const int dx[4] = { 1,0,-1,0 };
    const int dy[4] = { 0,1,0,-1 };
    const int N_size = 781; 
    const int N_size2 = 390;

    struct L_coord
    {
       unsigned int x;
       unsigned int y;
    };


    mma::IntMatrixRef CreateSandpile(int n ) {
        auto ra = mma::makeMatrix<mint>(N_size,N_size);
        std::fill(ra.begin(),ra.end(),0);
        bool** V_sites = new bool*[N_size];
        bool** Move_ = new bool*[N_size];
        unsigned int** Odometer = new unsigned int*[N_size];

       for (int k = 0; k < N_size; k++)
       {
         V_sites[k] = new bool[N_size];
         Odometer[k] = new unsigned int[N_size];
         Move_[k] = new bool[N_size];

         for (int i = 0; i<N_size; i++)
         {
          Move_[k][i] = false; V_sites[k][i] = false;
         }
       }

       L_coord* walking_ = new L_coord[N_size*N_size];        
       V_sites[N_size2][N_size2] = true;
       Move_[N_size2][N_size2] = true;
       ra(N_size2,N_size2) = n;
       walking_[0].x = N_size2;
       walking_[0].y = N_size2;  
       unsigned int x = 0, y = 0;
       int top_ = 0;
       unsigned int lx = 0, ly = 0;
       unsigned int d = 0; 
       unsigned int max_of_top = 0;
       unsigned long N_of_Moves = 0;

       while (top_ >= 0)
       {
         N_of_Moves += 1;
         if (max_of_top < top_) { max_of_top = top_; }

         x = walking_[top_].x;  y = walking_[top_].y;

         top_--; Move_[x][y] = false;

         d = (ra(x,y) >> 2);
         ra(x,y) = ra(x,y) - (d << 2);

         for (int k = 0; k < 4; k++)
         {
          lx = x + dx[k];
          ly = y + dy[k];

          V_sites[lx][ly] = true;
          ra(lx,ly) += d;
          if (Move_[lx][ly] == false && ra(lx,ly) >= 4)
          {
              walking_[++top_].x = lx; 
              walking_[top_].y = ly; 
              Move_[lx][ly] = true;
          }
         }
       }

        for (int k = 0; k<N_size; k++)
        {
            delete[] V_sites[k]; delete[] Odometer[k]; delete[] Move_[k];
        }
        delete[] V_sites;
        delete[] Odometer;
        delete[] Move_;
        delete[] walking_;
        return ra;
    }
};